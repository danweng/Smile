﻿$(document).ready(function () {
	$("#submit").click(function () {
		alert("感謝您的投票!");
	});
});